/**
This file is replaced by an auto-generated version.h
with an OSQP_VERSION obtained from a variable supplied
to cmake
*/

#ifndef OSQP_VERSION
#define OSQP_VERSION "1.0.0"
#endif
